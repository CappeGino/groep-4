// rename this file to secrets.js
// and enter your public access token
// from your account on https://account.mapbox.com
const mapboxAccessToken = 'pk.eyJ1IjoiZGFsaXJ1bm8iLCJhIjoiY2xwNnhpNWxjMXVqZTJrcWsyM2k2b2dzYyJ9.uEjNNPkBHiLCU7T2tJlUhA';
