// rename this file to secrets.js
// and enter your public access token
// from your account on https://account.mapbox.com
const mapboxAccessToken = 'your mapbox access token here';
